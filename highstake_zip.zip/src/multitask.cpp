#include "vex.h";


int lift_(int level){
  switch (level)
      case 1:
      
      break;

      case 2:

      break;

      case 3:
      
      break;
      


  while(true)
  {
    
    vex::task::sleep(100);
  }
  return 1;

}