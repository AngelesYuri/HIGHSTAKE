#include "vex.h"

void red_side_right();

void red_side_middle();

void blue_side_right();

void blue_side_middle();

void drivetrain_test();
