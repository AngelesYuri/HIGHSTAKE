#include "vex.h"


void dunk(bool dunks_switch);

void lift_at_level(int level,bool lift_switch);

void sorter_(bool sorter_switch,int sorter_color);
